
// 求人応募用GoogleフォームのURL
export const GOOGLE_FORM_URL = "https://forms.gle/ruyZFiEPAUN765bH8";
